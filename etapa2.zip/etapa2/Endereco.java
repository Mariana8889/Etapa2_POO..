/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Endereco {
    static String cidade = "Cataguases";
    private String bairro, rua;
    private int numero, cep;
    
    public Endereco (String b, String r, int n, int cp)
    {
        this.bairro = b;
        this.rua = r;
        this.numero = n;
        this.cep = cp;
    }
    
    public void setBairro(String b) 
    {
        this.bairro = b;
    }
    public String getBairro(String b)
    {
        return bairro;
    }
    
    public void setRua(String r) 
    {
        this.rua = r;
    }
    public String getRua(String r)
    {
        return rua;
    }
    
    public void setNumero(int n) 
    {
        this.numero = n;
    }
    public int getNumero(int n)
    {
        return numero;
    }
    
    public void setCep(int c) 
    {
        this.cep = c;
    }
    public int getCep(int c)
    {
        return cep;
    }
    
  public String toString()
  {
      return cidade + "; " + this.bairro + "; " + this.rua + " - " + this.numero +"; " + this.cep;  
  }
    
}
