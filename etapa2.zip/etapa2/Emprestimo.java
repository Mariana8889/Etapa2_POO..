/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Emprestimo {
    private int maxlivros = 3;
    private int quant;
    private int codigo;
    private Data data_retorno, data_prazo, data_retirada;
    private Usuarios cliente;
    private Funcionarios func;
    Livros livro[];
    int i;
    
     public Emprestimo (int cod, Data dr, Data dp, Usuarios c, Funcionarios f)
    {
        this.data_prazo = dp;
        this.data_retirada = dr;
        this.data_retorno = new Data(0,0,0);
        this.codigo = cod;
        this.cliente = c;
        this.func = f;
        livro = new Livros[maxlivros];
        quant = 0;
    }
     
     
     public void setCodigo(int cod) 
    {
        this.codigo = cod;
    }
    public int getCodigo()
    {
        return codigo;
    }
    
    public void setData_retorno(Data drn) 
    {
        this.data_retorno = drn;
    }
    public Data getData_retorno()
    {
        return data_retorno;
    }
    public void setData_retirada(Data drn) 
    {
        this.data_retirada = drn;
    }
    public Data getData_retirada()
    {
        return data_retirada;
    }
    public void setData_prazo(Data drn) 
    {
        this.data_prazo = drn;
    }
    public Data getData_prazo()
    {
        return data_prazo;
    }
    
      public void setCliente(Usuarios c) 
    {
        this.cliente = c;
    }
    public Usuarios getCliente()
    {
        return cliente;
    }
   
      public void setFunc (Funcionarios f) 
    {
        this.func = f;
    }
    public Funcionarios getFunc()
    {
        return func;
    }
    
    public void AdicionaData (Data drt)
    {
        data_retorno = drt;
         if((data_retorno.dia!=data_prazo.dia)&&(data_retorno.mes!=data_prazo.mes)&&(data_retorno.ano!=data_prazo.ano)&&(data_retorno.dia!=0))
         {
             this.cliente.Faltas();
         }
    }
    
   
    public void AdicinarLivros (Livros lv)
    {
        if (quant<maxlivros)
        {
            livro[quant] = lv;
            quant++;
        }
        else
        {
            System.out.printf("\n\nQuantidade máxima de livros expirada!");
        }
    }
   
    public void InformaLivrosEmprestados ()
    {
        System.out.printf("\n\nLivros retirados:\n");
        for (i=0;i<quant;i++)
        {
            livro[i].InformaLivros();
        }
    } 
    
    public void InformaEmprestimos ()
    {
        if((data_retorno.dia!=data_prazo.dia)&&(data_retorno.mes!=data_prazo.mes)&&(data_retorno.ano!=data_prazo.ano)&&(data_retorno.dia!=0))
        {
            System.out.println("\nInformações do Emprestimo:\n\nNúmero de Identificação:" + this.codigo + "\nFuncionário:" + this.func.getIdentificador() + "\nNome do usuário: " + this.cliente.getCpf() + "\nData de retirada: " + this.data_retirada + "\nPazo de entrega: " + this.data_prazo + "\nData de retorno: " + this.data_retorno + "\nMulta: R$: 10,00.");
            this.InformaLivrosEmprestados();
        }
        else if (data_retorno.dia==0)
        {
            System.out.println("\nInformações do Emprestimo:\n\nNúmero de Identificação:" + this.codigo + "\nFuncionário:" + this.func.getIdentificador() + "\nNome do usuário: " + this.cliente.getCpf() + "\nData de retirada: " + this.data_retirada + "\nPazo de entrega: " + this.data_prazo + "\nData de retorno: Ainda não entregue.");
            this.InformaLivrosEmprestados();
        }
        else
        {
            System.out.println("\nInformações do Emprestimo:\n\nNúmero de Identificação:" + this.codigo + "\nFuncionário:" + this.func.getIdentificador() + "\nNome do usuário: " + this.cliente.getCpf() + "\nData de retirada: " + this.data_retirada + "\nPazo de entrega: " + this.data_prazo + "\nData de retorno: " + this.data_retorno);
            this.InformaLivrosEmprestados();
        }
                
    }
}
