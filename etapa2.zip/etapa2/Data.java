/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Data {
    int dia, mes, ano;
    
    public Data(int d, int m, int a){
       dia = d;
       mes = m;
       ano = a;
    }
    
     public String toString(){
        return Integer.toString(dia) + "/" + Integer.toString(mes) + "/" + Integer.toString(ano);
    }
}
