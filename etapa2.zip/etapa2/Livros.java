/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Livros {
    
    private String nome_livro, autor;
    private int paginas;
    
    
    public Livros(String nl, String a, int p) 
    {
        this.nome_livro = nl;
        this.autor = a;
        this.paginas = p;
    }
    
    public void setNome_Livro(String nl) 
    {
        this.nome_livro = nl;
    }
    public String getNome_Livro()
    {
        return nome_livro;
    }
    
    public void setAutor(String a) 
    {
        this.autor = a;
    }
    public String getAutor()
    {
        return autor;
    }
    
     public void setPaginas(int p) 
    {
        this.paginas = p;
    }
    public int getPaginas()
    {
        return paginas;
    }
  
   public void InformaLivros ()
   {
       System.out.printf("Nome: %s;\nAutor: %s;\nPáginas:%d\n\n", nome_livro, autor, paginas);
   }
    
}
