/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Funcionarios extends Pessoa {
    private String periodo;
    private int identificador;
    double salario;
    
    public Funcionarios (String p, int i)
    {
        this.periodo = p;
        this.identificador = i;
    }
    
     public void setPeriodo(String p) 
    {
        this.periodo = p;
    }
    public String getPeriodo()
    {
        return periodo;
    }
    
     public void setIdentificador(int i) 
    {
        this.identificador = i;
    }
    public int getIdentificador()
    {
        return identificador;
    }
    
    public void CalculoSalario()
    {
        salario = 1000 + 50*lista.size();
    }
    
     public void InformaFuncionario ()
    {
        System.out.println ("\n\nInformações do funcionário:\nIdentificador:" + this.identificador + "\nSalário: R$" + this.salario +"\nNome: " + this.getNome() +"\nCPF: " + this.getCpf() + "\nEndereço: " + this.getEnd() + "\nTelefone" + this.getTelefone() + "\nPeríodo: " + this.periodo);  
    }
}
