/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Usuarios extends Pessoa{
    private int falta;
    
    public Usuarios(){}
    
    public void Faltas()
    {
        falta++;
    }
    
    public void InformaUsuario ()
    {
        System.out.println ("\n\nInformações do usuário:\nNome: " + this.getNome() +"\nCPF: " + this.getCpf() + "\nEndereço: " + this.getEnd() + "\nTelefone" + this.getTelefone());  
 
    }
}
