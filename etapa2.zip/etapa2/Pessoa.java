/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author W10
 */
public class Pessoa {
    private String nome,cpf, telefone;
    private Endereco end;
    int i, numlista;
    ArrayList<Emprestimo> lista = new ArrayList();
    Scanner leitor = new Scanner(System.in);
    
    public Pessoa(){}
    
    public void setNome(String n) 
    {
        this.nome = n;
    }
    public String getNome()
    {
        return nome;
    }
    
    public void setCpf(String c) 
    {
        this.cpf = c;
    }
    public String getCpf()
    {
        return cpf;
    }
    
    public void setTelefone(String tel) 
    {
        this.telefone = tel;
    }
    public String getTelefone()
    {
        return telefone;
    }
    
      public void setEnd(Endereco e) 
    {
        this.end = e;
    }
    public Endereco getEnd()
    {
        return end;
    }
    
    public void AdicionarEmprestimos(Emprestimo emp)
    {
        lista.add(emp);
    }
    
    public void MostrarEmprestimosRealizados()
    {
        for(i=0;i<lista.size();i++)
        {
            System.out.println("- " + lista.get(i).getCodigo() + "\n");  
        }
        System.out.printf("\nDeseja ver as informações de alguma operação? (insira o código)\n-> ");
        numlista = leitor.nextInt();
        for(i=0;i<lista.size();i++)
        {
            if(lista.get(i).getCodigo()==numlista)
            {
                lista.get(i).InformaEmprestimos();
            } 
        }
    }    
}
