/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package etapa2;

/**
 *
 * @author W10
 */
public class Etapa2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Endereco ed1 = new Endereco ("Vila Reis", "Rua Galvão", 22, 2234776);
        Usuarios u1 = new Usuarios();
        Funcionarios f1 = new Funcionarios("Manhã", 1);
        Livros l1 = new Livros("Um Milhão de Finais Felizes", "Vitor Martins", 239);
        Livros l2 = new Livros("O Hobbit", "JRR Tolkien", 434);
        Livros l3 = new Livros("Cidades de Papel", "John Green", 331);
        
         u1.setCpf("63782928383");
       u1.setEnd(ed1);
       u1.setNome("Maria Lucia");
       u1.setTelefone("61818929891");
       
       f1.setCpf("72829837982");
       f1.setEnd(ed1);
       f1.setNome("Mauro Augusto");
       f1.setTelefone("172819496");
        
       /* operações teste:
        u1.InformaUsuario();
        l1.InformaLivros();
       */
      
        Emprestimo e1 = new Emprestimo (1, new Data(9,12,2021), new Data(22,12,2021), u1, f1);
        e1.AdicinarLivros(l1);
        e1.AdicinarLivros(l2);
        e1.AdicinarLivros(l3);
        /*;
        e1.AdicionaData(new Data(22,12,2021));
        e1.InformaEmprestimos();
        e2.InformaLivrosEmprestados();*/
        
        Emprestimo e2 = new Emprestimo (2, new Data(9,12,2021), new Data(22,12,2021), u1,f1);
        e2.AdicinarLivros(l1);
        e2.AdicinarLivros(l2);
        /*
        e2.AdicionaData(new Data (23,12,2021));
        e2.InformaEmprestimmos();*/
        
      /* u1.AdicionarEmprestimos(e2);
       u1.AdicionarEmprestimos(e1);
       u1.MostrarEmprestimosRealizados();*/
      
      /*
       f1.AdicionarEmprestimos(e2);
       f1.AdicionarEmprestimos(e2);
       f1.CalculoSalario();
       f1.InformaFuncionario();*/
 
        
    }
    
   
    
}
